@extends('layout')

@section('content')
    <h1>Coding Exercise</h1>
    <!-- TODO -->
@endsection
