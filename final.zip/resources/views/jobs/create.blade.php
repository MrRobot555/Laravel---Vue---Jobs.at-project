@extends('layout')

@section('content')
    <h1>Add job</h1>
    <!-- TODO -->
@endsection
