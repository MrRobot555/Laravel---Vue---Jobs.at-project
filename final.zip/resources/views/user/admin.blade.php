@extends('layout')

@section('content')
    <h1>Login as admin</h1>
    <!-- TODO -->
@endsection
