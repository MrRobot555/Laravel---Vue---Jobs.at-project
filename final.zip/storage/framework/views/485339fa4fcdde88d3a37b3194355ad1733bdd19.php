<?php $__env->startSection('content'); ?>
    <h1>Coding Exercise</h1>
    <!-- TODO -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\working\laravel-vue-master\laravel-vue-master\resources\views/index.blade.php ENDPATH**/ ?>